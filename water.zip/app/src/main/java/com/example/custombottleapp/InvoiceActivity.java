
package com.example.custombottleapp;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class InvoiceActivity extends AppCompatActivity {

    Button btnGenerate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invoice);

        btnGenerate = findViewById(R.id.btnGeneratePdf);
        btnGenerate.setOnClickListener(v -> {
            generatePdfInvoice();
        });
    }

    private void generatePdfInvoice() {
        PdfDocument document = new PdfDocument();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(300, 600, 1).create();
        PdfDocument.Page page = document.startPage(pageInfo);

        Canvas canvas = page.getCanvas();
        Paint paint = new Paint();
        paint.setTextSize(12);
        int y = 25;
        canvas.drawText("Custom Bottle Invoice", 10, y, paint);
        y += 20;
        canvas.drawText("Order ID: SAMPLE123", 10, y, paint);
        y += 20;
        canvas.drawText("Brand Name: Vishal Water", 10, y, paint);
        y += 20;
        canvas.drawText("Quantity: 100", 10, y, paint);
        y += 20;
        canvas.drawText("Total: ₹5000", 10, y, paint);

        document.finishPage(page);

        String target = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getPath()+"/invoice_sample.pdf";
        File filePath = new File(target);
        try {
            document.writeTo(new FileOutputStream(filePath));
            Toast.makeText(this, "PDF saved to Downloads", Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            Toast.makeText(this, "Error: "+e.getMessage(), Toast.LENGTH_LONG).show();
        }
        document.close();
    }
}
