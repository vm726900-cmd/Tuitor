
package com.example.custombottleapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import org.json.JSONObject;

public class CheckoutActivity extends AppCompatActivity implements PaymentResultListener {

    EditText etAddress;
    Button btnPlaceOrder;
    FirebaseFirestore db;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        etAddress = findViewById(R.id.etAddress);
        btnPlaceOrder = findViewById(R.id.btnPlaceOrder);
        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();

        // initialize razorpay
        Checkout.preload(getApplicationContext());

        btnPlaceOrder.setOnClickListener(v -> {
            String addr = etAddress.getText().toString().trim();
            if (TextUtils.isEmpty(addr)) {
                Toast.makeText(CheckoutActivity.this, "Address required", Toast.LENGTH_SHORT).show();
                return;
            }
            String uid = auth.getCurrentUser() != null ? auth.getCurrentUser().getUid() : "guest";
            Query q = db.collection("orders").whereEqualTo("userId", uid).whereEqualTo("status", "Pending");
            q.get().addOnSuccessListener(queryDocumentSnapshots -> {
                // For simplicity assume single pending order and fixed amount calculation
                for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                    doc.getReference().update("address", addr);
                }
                // Start payment (demo). In production, create order on server and fetch order_id
                startRazorpayPayment(100); // amount in INR (demo)
            }).addOnFailureListener(e -> {
                Toast.makeText(CheckoutActivity.this, "Failed: "+e.getMessage(), Toast.LENGTH_LONG).show();
            });
        });
    }

    private void startRazorpayPayment(int amountInRupees) {
        Checkout checkout = new Checkout();
        // key is read from Manifest meta-data in real app or from secure server
        checkout.setKeyID("rzp_test_yourkey_here");
        try {
            JSONObject options = new JSONObject();
            options.put("name", "Custom Bottle");
            options.put("description", "Order payment");
            options.put("currency", "INR");
            options.put("amount", amountInRupees * 100); // paise

            JSONObject prefill = new JSONObject();
            prefill.put("email", auth.getCurrentUser() != null ? auth.getCurrentUser().getEmail() : "demo@example.com");
            prefill.put("contact", "9999999999");
            options.put("prefill", prefill);

            checkout.open(this, options);
        } catch (Exception e) {
            Toast.makeText(this, "Error in payment: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onPaymentSuccess(String s) {
        // update orders as paid
        String uid = auth.getCurrentUser() != null ? auth.getCurrentUser().getUid() : "guest";
        Query q = db.collection("orders").whereEqualTo("userId", uid).whereEqualTo("status", "Pending");
        q.get().addOnSuccessListener(queryDocumentSnapshots -> {
            for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                doc.getReference().update("paymentStatus", "Paid", "status", "Printing");
            }
        });
        startActivity(new Intent(this, ProductListActivity.class));
        finish();
    }

    @Override
    public void onPaymentError(int i, String s) {
        Toast.makeText(this, "Payment failed: "+s, Toast.LENGTH_LONG).show();
    }
}
