
package com.example.custombottleapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.HashMap;
import java.util.Map;

public class CustomizeActivity extends AppCompatActivity {

    private static final int PICK_IMAGE = 100;
    ImageView imgPreview;
    Uri imageUri;
    EditText etBrandName, etQuantity;
    Spinner spSize;
    Button btnUpload, btnAddToCart;
    ProgressBar progressBar;
    StorageReference storageRef;
    FirebaseFirestore db;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customize);

        imgPreview = findViewById(R.id.imgPreview);
        etBrandName = findViewById(R.id.etBrandName);
        etQuantity = findViewById(R.id.etQuantity);
        spSize = findViewById(R.id.spSize);
        btnUpload = findViewById(R.id.btnUpload);
        btnAddToCart = findViewById(R.id.btnAddToCart);
        progressBar = findViewById(R.id.progressBar);

        storageRef = FirebaseStorage.getInstance().getReference("logos");
        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();

        btnUpload.setOnClickListener(v -> {
            Intent gallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
            startActivityForResult(gallery, PICK_IMAGE);
        });

        btnAddToCart.setOnClickListener(v -> {
            String brand = etBrandName.getText().toString().trim();
            String qtyStr = etQuantity.getText().toString().trim();
            String size = spSize.getSelectedItem().toString();
            if (brand.isEmpty() || qtyStr.isEmpty()) {
                Toast.makeText(CustomizeActivity.this, "भरा हुआ नाम और मात्रा दर्ज करें", Toast.LENGTH_SHORT).show();
                return;
            }
            int qty = Integer.parseInt(qtyStr);
            progressBar.setVisibility(View.VISIBLE);
            if (imageUri != null) {
                StorageReference ref = storageRef.child(System.currentTimeMillis()+".jpg");
                ref.putFile(imageUri).addOnSuccessListener(taskSnapshot -> ref.getDownloadUrl().addOnSuccessListener(uri -> {
                    String logoUrl = uri.toString();
                    createOrder(brand, size, qty, logoUrl);
                })).addOnFailureListener(e -> {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(CustomizeActivity.this, "Image upload failed: "+e.getMessage(), Toast.LENGTH_LONG).show();
                });
            } else {
                // no image
                createOrder(brand, size, qty, "");
            }
        });
    }

    private void createOrder(String brand, String size, int qty, String logoUrl) {
        String uid = auth.getCurrentUser() != null ? auth.getCurrentUser().getUid() : "guest";
        Map<String, Object> order = new HashMap<>();
        order.put("userId", uid);
        order.put("brandName", brand);
        order.put("logoUrl", logoUrl);
        order.put("bottleSize", size);
        order.put("quantity", qty);
        order.put("status", "Pending");
        order.put("timestamp", System.currentTimeMillis());
        db.collection("orders").add(order).addOnSuccessListener(documentReference -> {
            progressBar.setVisibility(View.GONE);
            Toast.makeText(CustomizeActivity.this, "Order placed", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(CustomizeActivity.this, ProductListActivity.class));
            finish();
        }).addOnFailureListener(e -> {
            progressBar.setVisibility(View.GONE);
            Toast.makeText(CustomizeActivity.this, "Order failed: "+e.getMessage(), Toast.LENGTH_LONG).show();
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == PICK_IMAGE && data != null) {
            imageUri = data.getData();
            try {
                Glide.with(this).load(imageUri).into(imgPreview);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
