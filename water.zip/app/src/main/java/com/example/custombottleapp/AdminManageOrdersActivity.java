
package com.example.custombottleapp;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class AdminManageOrdersActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<String> items = new ArrayList<>();
    ArrayList<DocumentSnapshot> docs = new ArrayList<>();
    ArrayAdapter<String> adapter;
    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_orders);

        listView = findViewById(R.id.listViewOrders);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
        listView.setAdapter(adapter);
        db = FirebaseFirestore.getInstance();

        // Listen to orders collection
        db.collection("orders").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(QuerySnapshot value, FirebaseFirestoreException error) {
                if (error != null) {
                    Toast.makeText(AdminManageOrdersActivity.this, "Error: "+error.getMessage(), Toast.LENGTH_LONG).show();
                    return;
                }
                items.clear();
                docs.clear();
                if (value != null) {
                    for (DocumentSnapshot doc : value.getDocuments()) {
                        String brand = doc.getString("brandName");
                        String status = doc.getString("status");
                        Long qtyL = doc.getLong("quantity");
                        String qty = qtyL != null ? String.valueOf(qtyL) : "1";
                        items.add("Order: "+doc.getId()+" | "+brand+" | Qty:"+qty+" | "+status);
                        docs.add(doc);
                    }
                }
                adapter.notifyDataSetChanged();
            }
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {
            DocumentSnapshot doc = docs.get(position);
            String[] options = new String[]{"Pending","Printing","Packed","Dispatched","Delivered","Cancel"};
            AlertDialog.Builder b = new AlertDialog.Builder(AdminManageOrdersActivity.this);
            b.setTitle("Update status for "+doc.getId());
            b.setItems(options, (dialog, which) -> {
                String sel = options[which];
                Map<String, Object> upd = new HashMap<>();
                upd.put("status", sel);
                doc.getReference().update(upd).addOnSuccessListener(aVoid -> {
                    Toast.makeText(AdminManageOrdersActivity.this, "Status updated", Toast.LENGTH_SHORT).show();
                }).addOnFailureListener(e -> {
                    Toast.makeText(AdminManageOrdersActivity.this, "Update failed: "+e.getMessage(), Toast.LENGTH_LONG).show();
                });
            });
            b.show();
        });
    }
}
