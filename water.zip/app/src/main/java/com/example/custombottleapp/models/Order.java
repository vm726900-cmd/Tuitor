
package com.example.custombottleapp.models;

public class Order {
    public String orderId;
    public String userId;
    public String brandName;
    public String logoUrl;
    public String bottleSize;
    public long quantity;
    public String status;
    public String address;
    public double totalAmount;

    public Order() {}

    public Order(String orderId, String userId, String brandName, String logoUrl,
                 String bottleSize, long quantity, String status, String address, double totalAmount) {
        this.orderId = orderId;
        this.userId = userId;
        this.brandName = brandName;
        this.logoUrl = logoUrl;
        this.bottleSize = bottleSize;
        this.quantity = quantity;
        this.status = status;
        this.address = address;
        this.totalAmount = totalAmount;
    }
}
