
package com.example.custombottleapp;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class ReportsAdminActivity extends AppCompatActivity {

    TextView tvTotalOrders, tvTotalQty, tvTotalRevenue;
    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports);

        tvTotalOrders = findViewById(R.id.tvTotalOrders);
        tvTotalQty = findViewById(R.id.tvTotalQty);
        tvTotalRevenue = findViewById(R.id.tvTotalRevenue);
        db = FirebaseFirestore.getInstance();

        // simple summary: count orders and sum quantities and price (if price field exists)
        db.collection("orders").get().addOnSuccessListener((QuerySnapshot snapshots) -> {
            int orders = 0;
            long totalQty = 0;
            double totalRevenue = 0.0;
            for (QueryDocumentSnapshot doc : snapshots) {
                orders++;
                Long q = doc.getLong("quantity");
                if (q != null) totalQty += q;
                Double price = doc.getDouble("totalAmount");
                if (price != null) totalRevenue += price;
            }
            tvTotalOrders.setText("Total Orders: "+orders);
            tvTotalQty.setText("Total Quantity: "+totalQty);
            tvTotalRevenue.setText("Total Revenue: ₹"+totalRevenue);
        }).addOnFailureListener(e -> {
            Toast.makeText(ReportsAdminActivity.this, "Failed to load reports: "+e.getMessage(), Toast.LENGTH_LONG).show();
        });
    }
}
