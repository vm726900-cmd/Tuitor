
package com.example.custombottleapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    private EditText etEmail, etPassword;
    private Button btnLogin, btnRegister;
    private ProgressBar progressBar;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnRegister = findViewById(R.id.btnRegister);
        progressBar = findViewById(R.id.progressBar);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etEmail.getText().toString().trim();
                String pass = etPassword.getText().toString().trim();
                if (TextUtils.isEmpty(email) || TextUtils.isEmpty(pass)) {
                    Toast.makeText(LoginActivity.this, "Enter email and password", Toast.LENGTH_SHORT).show();
                    return;
                }
                progressBar.setVisibility(View.VISIBLE);
                mAuth.createUserWithEmailAndPassword(email, pass)
                        .addOnCompleteListener(task -> {
                            progressBar.setVisibility(View.GONE);
                            if (task.isSuccessful()) {
                                // create user doc with isAdmin=false
                                String uid = mAuth.getCurrentUser().getUid();
                                Map<String, Object> u = new HashMap<>();
                                u.put("email", email);
                                u.put("isAdmin", false);
                                db.collection("users").document(uid).set(u);
                                Toast.makeText(LoginActivity.this, "Registered", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(LoginActivity.this, "Register failed: "+task.getException(), Toast.LENGTH_LONG).show();
                            }
                        });
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etEmail.getText().toString().trim();
                String pass = etPassword.getText().toString().trim();
                if (TextUtils.isEmpty(email) || TextUtils.isEmpty(pass)) {
                    Toast.makeText(LoginActivity.this, "Enter email and password", Toast.LENGTH_SHORT).show();
                    return;
                }
                progressBar.setVisibility(View.VISIBLE);
                mAuth.signInWithEmailAndPassword(email, pass)
                        .addOnCompleteListener(task -> {
                            progressBar.setVisibility(View.GONE);
                            if (task.isSuccessful()) {
                                FirebaseUser user = mAuth.getCurrentUser();
                                // check isAdmin flag
                                db.collection("users").document(user.getUid()).get().addOnSuccessListener(documentSnapshot -> {
                                    boolean isAdmin = false;
                                    if (documentSnapshot.exists()) {
                                        Boolean b = documentSnapshot.getBoolean("isAdmin");
                                        isAdmin = b != null && b;
                                    }
                                    if (isAdmin) {
                                        startActivity(new Intent(LoginActivity.this, AdminManageOrdersActivity.class));
                                    } else {
                                        startActivity(new Intent(LoginActivity.this, ProductListActivity.class));
                                    }
                                    finish();
                                }).addOnFailureListener(e -> {
                                    // default to user
                                    startActivity(new Intent(LoginActivity.this, ProductListActivity.class));
                                    finish();
                                });
                            } else {
                                Toast.makeText(LoginActivity.this, "Login failed: " + task.getException(), Toast.LENGTH_LONG).show();
                            }
                        });
            }
        });
    }
}
