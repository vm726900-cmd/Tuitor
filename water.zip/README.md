
Custom Bottle App - Full Features Skeleton
------------------------------------------
Included features:
- Firebase Auth, Firestore, Storage integration (code included)
- Razorpay payment integration skeleton (client-side). For production use, create server-side order.
- FCM (Firebase Cloud Messaging) skeleton for push notifications (MyFirebaseService.java)
- PDF invoice generation using PdfDocument (InvoiceActivity.java)
- Admin reports (ReportsAdminActivity.java) that computes total orders, quantity and revenue

Important setup steps:
1. Firebase:
   - Create Firebase project, add Android app (package: com.example.custombottleapp)
   - Download google-services.json and put into app/ directory
   - Enable Authentication (Email/Password)
   - Setup Firestore, Storage and Messaging
2. Razorpay:
   - Add your Razorpay key in Manifest meta-data or better keep it on server
   - For production, create orders via your backend and send order_id to client.
   - See Razorpay docs: https://razorpay.com/docs/
3. FCM:
   - In Firebase Console -> Cloud Messaging, send messages manually for testing
   - To send programmatic notifications, use Firebase Admin SDK on server
4. Permissions:
   - Request runtime storage permissions for saving PDF on Android 6.0+
5. Build:
   - Open in Android Studio, Sync Gradle, add google-services.json, run on device/emulator.

Notes:
- This project is a working skeleton. You should harden security rules on Firestore and Storage.
- Replace demo keys and test data with real values.
